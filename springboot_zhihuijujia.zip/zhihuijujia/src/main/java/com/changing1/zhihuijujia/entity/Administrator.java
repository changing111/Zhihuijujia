/**
 * 
 */
package com.changing1.zhihuijujia.entity;

/**
 * @author: 陈骏贤
 * @date: 2021年4月8日
 * @version:
 * @Description:
 */
public class Administrator {
	private String aId;
	private String aPassword;
	private String aAuthority;
	public String getaId() {
		return aId;
	}
	public void setaId(String aId) {
		this.aId = aId;
	}
	public String getaPassword() {
		return aPassword;
	}
	public void setaPassword(String aPassword) {
		this.aPassword = aPassword;
	}
	public String getaAuthority() {
		return aAuthority;
	}
	public void setaAuthority(String aAuthority) {
		this.aAuthority = aAuthority;
	}
	
}
